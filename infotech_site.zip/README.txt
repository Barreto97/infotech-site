
INSTRUÇÕES:

1. Substitua "YOUR_FORM_ID" no index.html pelo seu Form ID do Formspree.
2. Substitua o link do iframe no script.js com o seu widget do Instagram (SnapWidget ou LightWidget).
3. Coloque sua logo como "logo.png" na mesma pasta.
4. Abra o index.html no navegador para visualizar.
5. Publique no GitHub Pages ou servidor.

Feito com ♥ por ChatGPT.
